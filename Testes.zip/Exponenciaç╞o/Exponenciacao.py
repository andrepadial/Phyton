valor = int(input('Informe um valor: '))
exponencial = int(input('Informe o exponencial: '))
cont = 0

while(cont <= valor):
    print(str(cont**exponencial))
    cont += 1
    
    
	
    
    