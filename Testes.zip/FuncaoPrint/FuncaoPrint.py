valor = int(input('Informe um número: '))
contador = 1

while (contador <= valor):
    print(contador, end='')
    contador += 1