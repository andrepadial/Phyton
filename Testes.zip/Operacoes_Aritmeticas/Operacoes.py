v1 = float(input("Informe o valor 1: "))
v2 = float(input("Informa o valor 2: "))

print(str(v1))
print(str(v2))

print(str(v1) + ' + ' + str(v2) + ' = ' + str(v1 + v2))
print(str(v1) + ' - ' + str(v2) + ' = ' + str(v1 - v2))
print(str(v1) + ' * ' + str(v2) + ' = ' + str(v1 * v2))
